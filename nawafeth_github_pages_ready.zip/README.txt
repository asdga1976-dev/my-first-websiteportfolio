موقع نوافذ شتر — جاهز لـ GitHub Pages

الملفات:
- index.html: الصفحة الرئيسية (لا تغيّر اسمه)
- images/: صور الأعمال المستخدمة في الموقع

طريقة النشر على GitHub Pages:
1. افتح https://github.com وسجّل الدخول أو أنشئ حسابًا.
2. اضغط + ثم New repository. سمِّ المستودع مثلاً nawafeth-shutter واجعله Public، ثم Create repository.
3. داخل المستودع اضغط Add file ثم Upload files.
4. ارفع index.html ومجلد images كاملًا (يمكنك سحب الملفات والمجلد إلى صفحة الرفع). اضغط Commit changes.
5. افتح Settings ثم Pages. تحت Build and deployment اختر Deploy from a branch، ثم Branch: main و Folder: /(root)، ثم Save.
6. انتظر حتى يظهر رابط ينتهي بـ github.io في صفحة Pages.

معلومات الموقع: رقم الاتصال 0532070197، واتساب يستخدم الرقم السعودي الدولي 966532070197. الموقع يعرض الرياض وجدة ومكة المكرمة.
